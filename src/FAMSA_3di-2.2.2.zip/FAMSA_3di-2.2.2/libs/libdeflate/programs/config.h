/* THIS FILE WAS AUTOMATICALLY GENERATED.  DO NOT EDIT. */
#ifndef CONFIG_H
#define CONFIG_H

/* Is the clock_gettime() function available? */
/* HAVE_CLOCK_GETTIME is not set */

/* Is the futimens() function available? */
/* HAVE_FUTIMENS is not set */

/* Is the futimes() function available? */
/* HAVE_FUTIMES is not set */

/* Is the posix_fadvise() function available? */
/* HAVE_POSIX_FADVISE is not set */

/* Is the posix_madvise() function available? */
/* HAVE_POSIX_MADVISE is not set */

/* Does stat() provide nanosecond-precision timestamps? */
/* HAVE_STAT_NANOSECOND_PRECISION is not set */

#endif /* CONFIG_H */
